import { abreviaturaUitlidades } from "./abreviaturaUtilidadess.js"; 
import { formatNumber } from "./formatNum.js"; 
export function calculateDiasDominical(divContainerActividades ,row, costoExterno, diaKamati, diasKamati,tipoDiaNoMover,abrvLinea,unidad, cant,{costoApl, costoTrs}, factorOAcValue,factorMoValue, polizaAcValue, viaticosValue,costoFinalAlimentacion,costoFinalTransporte,cantPersonas, recargoFestivoDominicalValue){
    if (tipoDiaNoMover === 'Dominical' && unidad === 'Dias' && cant) {
        let costoDia = (parseFloat(costoExterno) * recargoFestivoDominicalValue);
        let costoDiaKamati = (parseFloat(costoDia) + parseFloat(costoTrs) + parseFloat(costoApl)) * cantPersonas;
        let costoDiasKamati = (parseFloat(costoDiaKamati) * parseFloat(cant));
        if (!isNaN(costoDiaKamati) && !isNaN(costoDiasKamati)) {
            diaKamati.value = formatNumber(Math.round(costoDiaKamati));
            diasKamati.value = formatNumber(Math.round(costoDiasKamati));
            if (abrvLinea === "8" || abrvLinea === "12" || (abrvLinea !== "8" && abrvLinea !== "12")) {
                abreviaturaUitlidades(divContainerActividades, row, abrvLinea, costoDia, factorOAcValue, polizaAcValue, costoFinalAlimentacion, costoFinalTransporte, cantPersonas, viaticosValue, factorMoValue, cant);
            }
        }
    }
}