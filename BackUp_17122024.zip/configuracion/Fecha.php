<?php
date_default_timezone_set('America/Bogota');

// Obtener la fecha actual en el formato YYYY-MM-DD
$fechaActual = date('Y-m-d');
?>