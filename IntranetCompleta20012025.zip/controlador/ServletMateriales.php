<?php
// require_once '../controlador/ControladorCotizaciones.php';
// require_once '../modelo/ComercialProjects.php';
// require_once '../modelo/ViaticosCotizacion.php';
// require_once '../modelo/FactoresAdicionales.php';
// require_once '../modelo/dao/FactoresCotizacionesDao.php';
// require_once '../modelo/dao/FactorIndependienteDao.php';

// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//     $accion = $_POST['button_guardar_tabla_materiales'] ?? '';

//         switch ($accion) {
//             case 'GuardarTable':
               
//                 echo "<script>
//                         console.log('chupa')
//                         </script>

//                 ";
                
//                 break;
//         }
    
// }
?>