import { abreviaturaUitlidades } from "./abreviaturaUtilidadess.js";
import { formatNumber } from "./formatNum.js";
export function calculateDiaEntresemanas(divContainerActividades, row, costoExterno, diaKamati, diasKamati,tipoDiaNoMover,abrvLinea,unidad, cant,{costoApl, costoTrs}, factorOAcValue,factorMoValue, polizaAcValue, viaticosValue,costoFinalAlimentacion,costoFinalTransporte,cantPersonas) {
    if (tipoDiaNoMover === 'Dia_semana' && unidad === 'Dias' && cant) {
        let costoDiaKamati = (parseFloat(costoExterno) + parseFloat(costoTrs) + parseFloat(costoApl)) * cantPersonas;
        let costoDiasKamati = (parseFloat(costoDiaKamati) * parseFloat(cant));
        if (!isNaN(costoDiaKamati) && !isNaN(costoDiasKamati)) {
            diaKamati.value = formatNumber(Math.round(costoDiaKamati));
            diasKamati.value = formatNumber(Math.round(costoDiasKamati));
            if (abrvLinea === "8" || abrvLinea === "12" || (abrvLinea !== "8" && abrvLinea !== "12")) {
                abreviaturaUitlidades(divContainerActividades, row, abrvLinea, costoExterno, factorOAcValue, polizaAcValue, costoFinalAlimentacion, costoFinalTransporte, cantPersonas, viaticosValue, factorMoValue, cant);
            }
        }
    }
}